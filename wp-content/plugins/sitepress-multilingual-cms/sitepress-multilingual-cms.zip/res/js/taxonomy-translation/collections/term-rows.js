(function () {
    TaxonomyTranslation.collections.TermRows = Backbone.Collection.extend({
        model: TaxonomyTranslation.models.TermRow
    });
})(TaxonomyTranslation);